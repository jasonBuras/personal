public class Main {

    public static void main(String[] args){
        System.out.println("WordWhiz v2 (Literally a Wordle clone)\n" +
                "Author: Jason Buras\n");
        UI gameInterface = new UI();
        gameInterface.run();
    }
}
