public class Main {

    public static void main(String[] args){
        System.out.println("v1.1 Word Whiz (Literally a Wordle clone)\n" +
                "Author: Jason Buras\n");
        UI gameInterface = new UI();
        gameInterface.run();
    }
}
